package com.example.contacts;

import java.util.Comparator;

public class Contacts {

    String name;
    String phone;
    boolean isChecked = false;

    public static Comparator<Contacts> ContactsAZComparator = new Comparator<Contacts>() {
        @Override
        public int compare(Contacts C1, Contacts C2) {
            return C1.getName().compareTo(C2.getName());
        }
    };



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }


}
