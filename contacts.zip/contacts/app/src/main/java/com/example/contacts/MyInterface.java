package com.example.contacts;

public interface MyInterface {
    void onItemClick(int position);
    void onLongItemClick(int position);

}
